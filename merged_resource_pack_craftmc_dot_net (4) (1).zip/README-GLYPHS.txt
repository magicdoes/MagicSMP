README-GLYPHS

Kafal generated special unicode alternatives for normal font glyphs.
If a normal glyph looks too small in Bedrock, try the matching special unicode character instead.
IMPORTANT: update your Java/plugin config to use the special unicode character directly. The assigned special unicode may change in future conversions.

Columns: source_char | source_hex | target_char | target_hex | target_size | source_path | provider

 | EFF1 | 꿱 | AFF1 | 256x200 inside a 256x256 cell | assets/minecraft/textures/gui/sprites/container/brewing_stand/brewing_guide_left.png | minecraft:gui/sprites/container/brewing_stand/brewing_guide_left.png

All generated special unicode sheets use 256x256 cells. Each texture keeps its original aspect ratio and is fitted inside that cell with nearest-neighbor scaling.